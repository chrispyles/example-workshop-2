BEGIN_REGEX = r"\s*<!--\s*BEGIN \w+( NO PROMPT)?\s*-->\s*"
END_REGEX = r"\s*<!--\s*END \w+\s*-->\s*"
