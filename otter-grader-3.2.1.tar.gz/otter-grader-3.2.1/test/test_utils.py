"""Tests for ``otter.utils``"""

# TODO
